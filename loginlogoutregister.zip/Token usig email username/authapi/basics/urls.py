from atexit import register
from django.urls import path 
from basics import views
from django.conf.urls.static import static
from django.conf import settings
from basics.views import *

urlpatterns = [
    path('student/', views.StudentApi),
    path('student/<int:pk>',views.StudentApi),
    path("api-auth-token/",CustomAuthToken.as_view()),
    #path("register/",CreateUserView.as_view()),
    path("register/",CreateUser.as_view()),
    #path("register/",views.register_user),
    path("logout/",Logout.as_view()),

]