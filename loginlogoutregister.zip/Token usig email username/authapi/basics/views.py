import email
#from django.http import request
from django.shortcuts import render
#from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from basics import serializers
from basics.models import Student
from basics.serializers import StudentSerializer, RegisterSerializer
from rest_framework.decorators import api_view, permission_classes

from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated 

#@csrf_exempt
@api_view(['GET','POST','PUT','DELETE'])
@permission_classes([IsAuthenticated])
def StudentApi(request,id=None):
    if request.method=='GET':
        if id is not None:
            students=Student.objects.get(id=id)
            student_serializer=StudentSerializer(students)
            return Response(student_serializer.data)
        else:
            students=Student.objects.all()
            student_serializer=StudentSerializer(students,many=True)
            return Response(student_serializer.data)  
    elif request.method=='POST':
        student_data=JSONParser().parse(request)
        student_serializer=StudentSerializer(data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            return Response("Added sucessfully")
        return Response("Failed to add")
    elif request.method=='PUT':
        student_data=JSONParser().parse(request)
        student=Student.objects.get(id=student_data['id'])
        student_serializer=StudentSerializer(student,data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            return Response("Updated Sucessfully")
        return Response("Failed to update")
    elif request.method=='DELETE':
        student=Student.objects.get(id=id)
        student.delete()
        return Response("Deleted sucessfully")   


from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

class CustomAuthToken(ObtainAuthToken):

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email
        })

#@csrf_exempt

# @api_view(['POST'])
# def register_user(reuest):
#     #user_data=JSONParser().parse(request)
#     data=[]
#     serializer=RegisterSerializer(data=request.data)
#     if  serializer.is_valid():


#         user=serializer.save()

#         return Response({
#             'user_info': {
#                 "id": user.id,
#                 "username": user.username,
#                 "email": user.email
#             }
#         })
#     return Response("Failed to add")

# from rest_framework import generics
# from django.contrib.auth.models import User
from .serializers import RegisterSerializer

# class CreateUserView(generics.CreateAPIView):
#     queryset = User.objects.all()
#     serializer_class = RegisterSerializer


from django.contrib.auth.hashers import make_password
from rest_framework.views import APIView
class CreateUser(APIView):

    def post(self, request, format='json'):
        print(request.data)
        data = request.data
        reg_serializer = RegisterSerializer(data=data)
        if reg_serializer.is_valid():
            password = reg_serializer.validated_data.get('password')
            reg_serializer.validated_data['password']=make_password(password)
            new_user = reg_serializer.save()
            if new_user:
                return Response(status=status.HTTP_201_CREATED)
        return Response(reg_serializer.errors,status=status.HTTP_400_BAD_REQUEST)



from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

@permission_classes([IsAuthenticated])
class Logout(APIView):
    def get(self, request, format=None):
        # simply delete the token to force a login
        request.user.auth_token.delete()
        return Response("User logged out successfully", status=status.HTTP_200_OK)    

   